---
title: Prim算法模板
date: 2023-05-19 01:54:48
author: 长白崎
categories:
  - "算法"
tags:
  - "算法"
  - "Prim"
---

