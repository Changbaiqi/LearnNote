# 数位DP题目的讨论

---

## 说明：

> 就目前来说，所遇见的数位DP的题目类型主要可以分为以下几种类型：
>
> 1、各个位之间数字的差异统计
>
> 典型的题目有：[Classy Numbers - 洛谷 | 计算机科学教育新生态 (luogu.com.cn)](https://www.luogu.com.cn/problem/CF1036C)
>
> 2、数字的符合要求统计
>
> 典型的题目有：[P2657 [SCOI2009\] windy 数 - 洛谷 | 计算机科学教育新生态 (luogu.com.cn)](https://www.luogu.com.cn/problem/P2657)